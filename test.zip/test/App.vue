<script>
	export default {
	
		onLaunch: function() {
			console.log('App Launch')
			// 初始化全局变量
		},
		globalData: {
		   sharedData:1
		  },
		onShow: function() {
			console.log('App Show')
			 const sharedData = uni.getGlobalData().sharedData;
			    console.log(sharedData);
		},
		onHide: function() {
			console.log('App Hide')
		},
		
		
	}
</script>

<style>
	/*每个页面公共css */
</style>
