<template>
  <div class="container">
    <logo></logo>
    <div class="top-nav"> 
      <div class="search-bar">
        <div class="box01">
		 <input type="text" id="tip02" placeholder="软开社课程" class="top-nav-input" placeholder-style="color: #ef756e;">
	     </div>
        <img src="../static/assets/close.svg" alt="" class="deleteicon">
         
      </div> 
      
    </div>
    <downselect :activities="activities"></downselect>
    <div class="outcome">
      <span class="noutcome">
        32个结果
      </span>
    </div>
    <card @update-activities="handleUpdateActivities"></card>
  </div>
   <bottomtab></bottomtab>
</template>

<script>

// import 'element-plus/es/components/icon/style/css'
import bottomtab from '../components/bottomtabs.vue';
import downselect from '../components/downselect.vue';
import logo from "../components/logo.vue"
import card from "../components/card.vue"
// import { Close } from "@element-plus/icons";
export default {
  data() {
    
    return {   
      selectedDateOptions: [],  
     
      logoPath:"../../static/public/logo.png",
      topinputFortext:"软开社课程"

    };
  },
  
  components: {
    bottomtab,
    downselect,
    logo,
    card,
  },
  computed: {
    // 计算属性来获取数组的长度
    arrayLength() {
      return this.acttest.length;
    },
  },
  created() {
    
  },
  methods: {
   
    printActivityCount() {
      console.log('活动卡片数量:', this.acttest.length);
    },
    handleUpdateActivities(activities) {
      // 更新 activities 数据
      this.activities = activities;
      // 更新 selectedDate 下拉框的选项
      // this.updateSelectedDateOptions();
      console.log("99")
      console.log(activities)
    },
   formatDatetime(datetimeString) {
     
     // 创建一个新的Date对象
     const date = new Date(datetimeString);
   
     // 获取日期的各个部分
     const days = ['日', '一', '二', '三', '四', '五', '六'];
     const day = days[date.getDay()];
     const year = date.getFullYear();
     const month = date.getMonth() + 1; // getMonth() 返回的月份是从0开始的
     const dayOfMonth = date.getDate();
     const hours = date.getHours();
     const minutes = date.getMinutes();
   
     // 格式化时间
     let formattedTime = '';
     if (hours < 10) {
       formattedTime += '0';
     }
     formattedTime += hours + ':';
     if (minutes < 10) {
       formattedTime += '0';
     }
     formattedTime += minutes;
   
     // 拼接最终的日期时间字符串
     return `周${day}, ${month}月${dayOfMonth}日 · ${formattedTime}`;
   },  
  }
};
</script>

<style scoped>
#tip02{
         padding: 0 10px 0 35px;
         background-image: url('../../static/assets/s.svg');
         background-repeat: no-repeat;
         background-position: 10px 7px;
     }

     .box01{
        color: #434343;
        position: relative;
        margin-bottom: 5px;
		width: 85%;
		
     }
	 .search-input {
	   flex-grow: 1;
	   padding: 5px 35px 5px 35px;
	   
	   outline: none;
	   position: relative; /* 为伪元素定位做准备 */
	 }
.top-nav-input{
         -webkit-appearance: none;
         -moz-appearance: none;
         appearance:none ;
         outline: 0;
         font-size: 20px;
         font-weight: 600;
         color:rgba(239, 117, 110, 1);
         padding: 0 30px 0 15px;
}
	
.top-nav-input::placeholder{
	color:rgba(239, 117, 110, 1);
}
.outcome{

  height: 3%;
  widows: 100%;
  margin: 5%;
}
.noutcome{
  color:#626467;
  font-size: 14px;
  font-weight: 700;
  font-family: 'Inter';
}
.deleteicon{
    width: 25px;
    height: 20px;
    margin-left: 2%;
    margin-top: 0%;
}

svg{
  width: 1rem;
  height: 1rem;
}

.activity-pic{
  height: 80%;
  align-self: center; 
  margin-left: -2%;
}
.date{
  font-weight: 700;
  color: #EF756E;
  font-size: .7rem;
  line-height: 1.5vh;
}
.container {
  display: flex;
  flex-direction: column;
  height: 100%;
}
.deleteIcon{
  margin-right: -40%;
}


.top-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  
  
  width: 100%;
  margin: 0%;
}


.search-bar {
  display: flex;
  align-items: center;
  width: 100%;
  height: 80%;
  border-bottom: 1px solid #ccc;
  position: relative; 
}

/* .search-bar input {
  flex: 1;
  padding: 5px;
  border: 1px solid #ddd;
  border-radius: 20px;
  outline: none;
} */

.search-bar button {
  padding: 5px 10px;
  background-color: #ef756e;
  color: #fff;
  border: none;
  border-radius: 20px;
  cursor: pointer;
}


.activity-cards {
  flex: 1;
  overflow-y: auto;
  width: 95%;
}

.activity-card {
  display: flex; /* 使活动卡片横向排列 */
  border: 1px solid #ddd;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 10px;
}

.activity-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-self: center; 
  margin-left: 2%;
}

 .title {
  font-size: 1rem;
  font-weight: bold;
  line-height: 2.5vh
}

 .details {
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
}

.organizer {
  font-weight: 400;
  font-size: 0.7rem;
  margin-right: 56%;
  line-height: 1.5vh;
}
 .location {
  font-weight: 400;
  font-size: 0.7rem;
  margin-left: 15%;
  margin-top: -10%
}
.sidepic{
  align-self: center;
}
/* .likeicon{
  
}
.organizericon
{
  line-height: 3vh;
}
.shareicon
{
  
} */

.top-nav-input::placeholder
{
  color:#EF756E;

}
/* 响应式布局 */
/* @media (max-width: 768px) {
  .top-nav, .bottom-nav {
    flex-direction: column;
    align-items: center;
  }

  .top-nav .search-bar {
    width: 100%;
    margin-top: 10px;
  }

  .top-nav .tabs, .bottom-nav .tab {
    margin: 5px 0;
  }
} */
</style>