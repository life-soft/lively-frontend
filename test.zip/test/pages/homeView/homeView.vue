<template>
  <div class="container">
   
    <logo></logo>
    <card></card>
  </div>
   <bottomtab></bottomtab>
</template>

<script>
// import { ElIcon } from 'element-plus'
// import { Close } from '@element-plus/icons-vue'
// import 'element-plus/es/components/icon/style/css'
import bottomtab from '../components/bottomtabs.vue';
import downselect from '../components/downselect.vue';
import logo from "../components/logo.vue"
import card from "../components/card.vue"
// import { Close } from "@element-plus/icons";
export default {
  data() {
    
    return {    
      activities: [
        {
          pic:"huodongpic.png",
          title: '软开社第一次前端课程教学',
          date: '周五，2月3日·16:30-18:00',
          location: '教学楼311',
          organizer: 'HIAS软开社',
        },
        {
          pic:"huodongpic.png",
          title: '软开社第一次前端课程教学',
          date: '周五，2月3日·16:30-18:00',
          location: '教学楼311',
          organizer: 'HIAS软开社',
        },
        {
          pic:"huodongpic.png",
          title: '软开社第一次前端课程教学',
          date: '周五，2月3日·16:30-18:00',
          location: '教学楼311',
          organizer: 'HIAS软开社',
        },
        {
          pic:"huodongpic.png",
          title: '软开社第一次前端课程教学',
          date: '周五，2月3日·16:30-18:00',
          location: '教学楼311',
          organizer: 'HIAS软开社',
        },
     
      ],
      logoPath:"../../static/public/logo.png",
      topinputFortext:"软开社课程"

    };
  },
  
  components: {
    bottomtab,
    downselect,
    logo,
    card,
  },
  computed: {
    // 计算属性来获取数组的长度
    arrayLength() {
      return this.activities.length;
    },

  },
  methods: {
   
    printActivityCount() {
      console.log('活动卡片数量:', this.activities.length);
    }
  }
};
</script>

<style scoped>
.outcome{

  height: 3%;
  widows: 100%;
}
.noutcome{
  color:#626467;
  font-size: 1rem;
  font-weight: 700;
  font-family: 'Inter';
}
svg{
  width: 1rem;
  height: 1rem;
}

.activity-pic{
  height: 80%;
  align-self: center; 
  margin-left: -2%;
}
.activity-info .date{
  font-weight: 700;
  color: #EF756E;
  font-size: .7rem;
  line-height: 1.5vh;
}
.container {
  display: flex;
  flex-direction: column;
  height: 100%;
}
.deleteIcon{
  margin-right: -40%;
}
.logo{
  margin: 0 auto;
}

.top-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  background-color: #fff;
  
  width: 90%;
  margin: 0%;
}

.logo img {
  width: 100%;
}

.search-bar {
  display: flex;
  align-items: center;
}

.search-bar input {
  flex: 1;
  padding: 5px;
  border: 1px solid #ddd;
  border-radius: 20px;
  outline: none;
}

.search-bar button {
  padding: 5px 10px;
  background-color: #ef756e;
  color: #fff;
  border: none;
  border-radius: 20px;
  cursor: pointer;
}



.activity-cards {
  flex: 1;
  overflow-y: auto;
  width: 95%;
}

.activity-card {
  display: flex; /* 使活动卡片横向排列 */
  border: 1px solid #ddd;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 10px;
}

.activity-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-self: center; 
  margin-left: 2%;
}

.activity-info .title {
  font-size: 1rem;
  font-weight: bold;
  line-height: 2.5vh
}

.activity-info .details {
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
}

.activity-info .organizer {
  font-weight: 400;
  font-size: 0.7rem;
  margin-right: 56%;
  line-height: 1.5vh;
}
.activity-info .location {
  font-weight: 400;
  font-size: 0.7rem;
  margin-left: 15%;
  margin-top: -10%
}
.sidepic{
  align-self: center;
}
.likeicon{
  
}
.organizericon
{
  line-height: 3vh;
}
.shareicon
{
  
}
.top-nav input{
  font-size: 1rem;
  font-weight: 600;
}
.top-nav input::placeholder
{
  color:#EF756E;

}
/* 响应式布局 */
/* @media (max-width: 768px) {
  .top-nav, .bottom-nav {
    flex-direction: column;
    align-items: center;
  }

  .top-nav .search-bar {
    width: 100%;
    margin-top: 10px;
  }

  .top-nav .tabs, .bottom-nav .tab {
    margin: 5px 0;
  }
} */
</style>