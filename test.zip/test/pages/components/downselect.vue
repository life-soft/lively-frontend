<template>
  <div class="dropdown-selector">
   
   <!-- <select ref="tagSelect" @change="changeColor">
      <option v-for="(item, index) in tags1" :key="index" :value="item.value" :class="{ 'selected-option': item.value === selectedTag }">
        {{ item.text }}
      </option>
    </select> -->
 <picker mode="selector" :range="tags1" @change="selectTag">
      <button class="dropbtn">
		  <img src="../../static/assets/sliders.svg" alt="" class="imgbuttonleft" />
		    {{tagButtonText}}
		   <img src="../../static/assets/down.svg" alt="" class="imgbuttonright" />
	  </button>
    </picker>
	

  </div>
</template>


<script>
export default {
  props: {
    activities: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      tags1: [
        "11","22"
		
      ],
	  tagButtonText: '标签',
      selectedTag: '0', // 当前选中的标签
      isWeixin: false, // 用于判断是否在微信小程序平台
      isIos: false, // 用于判断是否在iOS平台
      isAndroid: false, // 用于判断是否在Android平台
    };
  },
  created(){
      	   
      	       	   uni.request({
      	       	   	  url: 'http://124.222.92.30:8080/system/tag/list',
      	       	   	  method: 'GET', 
      	       	   	  success: (res) => {
      	       	   	    if (res.statusCode === 200) {
      	       	   	      			 console.log("res.data.rows");
      	       	   	      			 console.log(res.data.rows);
									 let tagNames = res.data.rows.map(item => item.tagName);
									 console.log(res.data.rows[0].tagName);
									 console.log(tagNames);
									 this.tags1=tagNames;
      	       	   			   }
      	   					else {
      	   					// 服务器返回错误状态码
      	   					console.error('Error: Server returned status code:', res.statusCode);
      	       	   	    }
      	       	   		}
      	       	   	  })
      	       	   
      	       
      },
  methods: {
    
    changeColor(event) {
      // ...原有的 changeColor 方法
    },
	 showPicker() {
	      this.$refs.tagPicker.show();
	    },
	    selectTag(e) {
	      this.selectedTagIndex = e.detail.value;
		  console.log(e.detail.value)
		  console.log(e.detail)
		  console.log(e)
		  // 由于 tags1 是字符串数组，直接使用索引值获取选中的标签文本
		   let selectedText = this.tags1[this.selectedTagIndex] || '未找到标签文本';
		   console.log(selectedText); // 打印选择的标签文本
		   this.tagButtonText=selectedText;
		  
	    },
  },

  mounted() {
    const systemInfo = uni.getSystemInfoSync();
    this.isWeixin = systemInfo.platform === 'wechat';
    this.isIos = systemInfo.platform === 'ios';
    this.isAndroid = systemInfo.platform === 'android';
	
  }
};
</script>

<style scoped>
/* 通用样式 */
.dropdown-selector {
  display: flex;
}
	
.imgbuttonleft{
	width: 12px;
	height: 12px;
}
	
.imgbuttonright{
	width: 12px;
	height: 12px;
}
.selector {
  /* 微信小程序 picker-view 样式 */
}

.selector-ios {
  /* iOS 平台 picker-view 特殊样式 */
}

.selector-android {
  /* Android 平台 picker-view 特殊样式 */
}

.dropbtn {
   background-color: transparent; /* 移除背景颜色 */
    border: none; /* 移除边框 */
    padding: 0; /* 移除填充 */
    margin: 0; /* 移除外边距 */
    cursor: pointer; /* 显示手形指针，表示可点击 */
    outline: none; /* 移除聚焦轮廓 */
    font: inherit; /* 继承父元素的字体属性 */
    color: inherit; /* 继承父元素的文字颜色 */
	margin-left: 20%;
	width: 125%;
	background-color:rgba(255, 245, 238, 1);
    border-radius: 20px;
	font-size: 14px;
	font-weight: 700;
	line-height: 19.2px;
	top:4px;
	color: rgba(98, 100, 103, 1);
;
}

.selected-option {
  /* 选中的下拉选项样式 */
}
</style>