<template>
  <div class="bottom-nav">
    <div v-for="(tab, index) in tabs" :key="index" class="tab" :class="{active: tab.isActive}" @click="selectTab(index)">
      <img :src="tab.logoimg" class="imgbottom">
      {{ tab.name }}
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // ... 其他数据不变 ...
      tabs: [
        { name: '首页', index: 1, isActive: false, logoimg: `../../static/assets/home.svg` },
        { name: '搜索', index: 2, isActive: false, logoimg: `../../static/assets/search.svg` },
        { name: '收藏', index: 3, isActive: false, logoimg: `../../static/assets/love.svg` },
      ],
    };
  },
  created() {
    // 监听自定义事件并更新激活状态
    uni.$on('updateActiveTab', (index) => {
      this.updateTabActiveStatus(index);
    });
  },
  methods: {
    updateTabActiveStatus(index) {
      // 更新激活状态的方法
      this.tabs.forEach((tab, i) => {
        tab.isActive = i === index;
      });
    },
    selectTab(index) {
      this.updateTabActiveStatus(index);
      // 页面跳转逻辑...
      const tab = this.tabs.find(t => t.index === index);
      if (tab) {
        switch (index) {
          case 0:
            uni.navigateTo({
              url: "/pages/homeView/homeView"
            });
            break;
          case 1:
            uni.navigateTo({
              url: "/pages/searchView/searchView"
            });
            break;
          case 2:
            uni.navigateTo({
              url: "/pages/likeView/likeView"
            });
            break;
        }
      }
    },
    updateGlobalData() {
      // 更新globalData
      this.$global.setGlobalData((options) => {
        console.log(options.sharedData);
      });
    }
  },
  mounted() {
    // 在DOM更新完成后获取全局数据
    this.$nextTick(() => {
      const sharedData = this.$global.getGlobalData().sharedData;
     console.log(sharedData);
    });
  }
};
</script>

<style scoped>
svg.homeicon{
  width: 1rem;
  height: 1rem;
}
.tabs {
  display: flex;
  flex-direction: row; /* 将元素横向排列 */
  border: 1px solid red;
  background-color: aqua;
}

.bottom-nav {
  position: fixed; /* 固定导航栏位置 */
  left: 0; /* 从左侧开始 */
  right: 0; /* 到右侧结束 */
  bottom: 0; /* 位于屏幕底部 */
  display: flex;
  width: 100%; /* 宽度撑满屏幕 */
  background-color: #fff; /* 例如设置一个背景颜色 */
  box-shadow: 0 -1px 4px rgba(0, 0, 0, 0.1); /* 可选：为导航栏添加阴影效果 */
  z-index: 1000; /* 确保导航栏在内容之上 */
  height: 7%;
}
.imgbottom{
	height: 40px;
	width: 80%;
	
}

.tab {
  flex: 1; /* 确保每个.tab元素都占据相同的空间 */
  text-align: center; /* 使文本居中 */
  padding: 0%;
  display: grid;
  align-items: center; 
  justify-content: center;
  border-right: 1px solid #ebebeb; /* 添加右边框，除了最后一个元素 */
}

.tab:last-child {
  border-right: none; /* 移除最后一个.tab元素的右边框 */
}
.active{
	background-color: #ef756e;
	color: #fff;
}
.tab.active {
  background-color: #ef756e;
  color: #fff;
}


</style>