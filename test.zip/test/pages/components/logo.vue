<template>
    <div class="logo" :click=login>
        <!-- <div class="returnbutton">返回</div> -->
        <img src="../../static/public/logo.png" alt="活动力Logo" class="imglogo">     
      </div>
</template>
<script>
export default {
  data()
  {
    codeID:"";
  }
  
}

</script>
<style scoped>
.logo {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 50px; /* 容器的高度 */
  
}
	
.imglogo{
	
	height: 70%;
	width: 20%;
	  
}
.returnbutton{
  margin-left: 10px; /* 根据需要调整左边距 */
  padding: 5px 10px; /* 添加一些内边距 */
  border: 1px solid #fff; /* 设置白色边框 */
  background-color: transparent; /* 透明背景 */
  
  border-radius: 5px; /* 添加圆角 */
  cursor: pointer; 
}
</style>