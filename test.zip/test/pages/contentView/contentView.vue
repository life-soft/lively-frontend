<template>
  <div class="container">
    <logo></logo>
    <!-- <div v-if="shouldRender">
      <card @selectEvent="showEventDetails" />
    </div> -->
    <!-- <contentView :selectedEvent="selectedEvent" /> -->
    <!-- 在数据实际更新之前，模板可能已经尝试渲染。 -->
    <!-- <p>卡片索引: {{ eventDetails.eventId }}</p> -->
    <img :src="eventDetails.eventBanner" alt="Event Banner" class="detailpic">
    <div class="topbox">
      <h3 class="eventtitle">
        {{ eventDetails.eventName }}
      </h3>
        <div class="eventOrganizer">
        <img src="../../static/assets/user.svg" alt=""  class="imgOrganizer"/>
        {{ eventDetails.eventOrganizer }}
        </div>
        <div class="time">
          <img src="../../static/assets/time.svg" alt=""  class="imgtime">
          {{formatDatetime(eventDetails.eventStart)}}
        </div>
        <div class="eventDetail">
        <img src="../../static/assets/dw.svg" alt="" class="imgdetail" />
        {{ eventDetails.eventDetail }}
		 </div>
        <!-- <div class="locationDetail">
          <img src="../assets/province.svg" alt="" class="iconProvince">
          
          {{ eventDetails.eventProvince }}
          <img src="../assets/city.svg" alt="">
          
          {{ eventDetails.eventCity }}
          <img src="../assets/country.svg" alt="">
          
          {{ eventDetails.eventCounty }}
        </div> -->
     
    </div>
    <div class="detail">
      <span class="title">活动详情</span>
      <p class="text">
        {{ eventDetails.eventDesc }}
      </p>
    </div>
    <div class="bable" >
      <span class="title" @click="test">活动标签</span>
      <p v-for="(tag, index) in this.eventTags" :key="index" class="bable_span" >
      
        #{{ tag }}
      
      </p>
    </div>
  </div>
    
  


  
   
</template>

<script>

import bottomtab from '../components/bottomtabs.vue';
import downselect from '../components/downselect.vue';
import logo from "../components/logo.vue"
import card from "../components/card.vue"
import ContentView from './contentView';
// import { Close } from "@element-plus/icons";
 
export default {
  
  data() {
    
    return {    
      // card:null,
      // useindexcard:this.eventId,
      activities: [],
      selectedEvent: {},
      shouldRender: true,
      eventDetails: {},
      eventTags: [],
      formattedString:"",
	  codeID:"123",
    };
  },
  props: {
  //   selectedEvent: {
  //   type: Object,
  //   default: () => ({}),
  // },
  },
  components: {
    bottomtab,
    //downselect,
    logo,
    ContentView,
    card,
  },
  methods: {
    returnback(){
      this.$router.back();
    },
    updateEventTags(newTags) {
      this.eventTags = newTags;
    },
    formatDatetime(datetimeString) {
      
      // 创建一个新的Date对象
      const date = new Date(datetimeString);

      // 获取日期的各个部分
      const days = ['日', '一', '二', '三', '四', '五', '六'];
      const day = days[date.getDay()];
      const year = date.getFullYear();
      const month = date.getMonth() + 1; // getMonth() 返回的月份是从0开始的
      const dayOfMonth = date.getDate();
      const hours = date.getHours();
      const minutes = date.getMinutes();

      // 格式化时间
      let formattedTime = '';
      if (hours < 10) {
        formattedTime += '0';
      }
      formattedTime += hours + ':';
      if (minutes < 10) {
        formattedTime += '0';
      }
      formattedTime += minutes;

      // 拼接最终的日期时间字符串
      return `周${day}, ${month}月${dayOfMonth}日 · ${formattedTime}`;
    },  
    test()
    {
        const datetimeString = "2021-10-01 00:00:00";
        const formattedString = formatDatetime(datetimeString);
        console.log(formattedString); // 输出: 五, 10月1日 · 00:00
    },
  },
  onLoad: function(options) {
    // options 中包含了页面跳转时传递的所有参数
    const eventId = options.eventId;
    // 使用eventId进行后续操作，例如请求数据等
	wx.showToast({
	    title: 'ONLOAD '+eventId, // 这里可以根据需要自定义提示内容
	    icon: 'none', // 自定义图标，如果不需要可以省略这个选项
	    duration: 2000 // 展示时长，单位为毫秒
	  });
	   const apiUrl = 'http://124.222.92.30:8080/system/event/getInfo?eventId='+eventId;
	   uni.request({
	     url: apiUrl,
	     method: 'GET', // 默认就是 GET
	     success: (res) => {
	       if (res.statusCode === 200) {
	         // 请求成功，更新 activities 数组
	         this.activities = res.data.data;
			 console.log("res.data.data");
			 console.log(res.data.data);
			 console.log("res.data.data.eventTags");
			 console.log(res.data.data.eventTags);
			 console.log('res.data.data.eventDetail');
			 console.log(res.data.data.eventDetail);
	   		   if (this.activities!=null) {
	   		     this.eventTags=res.data.data.eventTags
				 console.log( this.eventTags);
	   		     console.log("this.activities.data.eventTags")
	   		     console.log(this.eventTags)
				 
	   		     this.eventDetails = res.data.data; // 保存解析后的数据
	   		     this.eventTime=res.data.data.eventTime
				console.log(this.eventDetails.eventStart)
	   		    let date=this.formatDatetime(this.eventDetails.eventStart)
	   		   console.log(date)
	   		     console.log("this.eventDetails")
	   		     console.log(this.eventDetails)
				 
	   		     console.log("this.eventDetails.eventBanner")
	   		     console.log(this.eventDetails.eventBanner)
	   		   }
	       } else {
	         // 服务器返回错误状态码
	         console.error('Error: Server returned status code:', res.statusCode);
	       }
	     },
	     fail: (error) => {
	       // 请求失败
	       console.error('Error fetching activities:', error);
	     }
	   });
  },
  created() {
       
      wx.login({
       	       success:function(res){
       	           if(res.code){
					   console.log("res.code为==");
					   console.log(res.code);
       				  const apiUrl = 'http://124.222.92.30:8080/system/OAuth/authByWX?code='+res.code;
       				  uni.request({
       				    url: apiUrl,
       				    method: 'POST', // 默认就是 GET
       				    success: (res) => {
       				      if (res.statusCode === 200) {
       				        // 请求成功，更新 activities 数组
							console.log(res.data.data.openid)
							// localStorage.setItem("openid",res.data.data.openid)
							// localStorage.getItem("openid")
       				        wx.showToast({
       				            title: res.data.openid, // 这里可以根据需要自定义提示内容
       				            icon: 'none', // 自定义图标，如果不需要可以省略这个选项
       				            duration: 2000,// 展示时长，单位为毫秒
       				          });   
       				      } 
       				    }  
       	           })
       	       }
       	   }
       	   })
  },
  computed: {
    // 使用计算属性来获取 index 参数
    index() {
		
      return this.$route.params.eventId;
    },
    
  },

};

</script>

<style scoped>
	.eventOrganizer, .time, .eventDetail {
	  display: flex; 
	  align-items: center;
		
		/* border: chartreuse 1px solid; */
	}
	
	.imgOrganizer, .imgtime, .imgdetail {
	  margin-right: 5px; 
	}
.imgOrganizer{
	  width:10%; /* 设置宽度为自动，保持原始宽高比 */
	  height: 25px; /* 设置高度 */
	max-width: 100%; /* 设置最大宽度为容器宽度的100%，防止溢出 */
	  object-fit: contain; /* 保持图像的完整，同时调整图像以适应容器 */
}	
.imgdetail{
	width:10%; /* 设置宽度为自动，保持原始宽高比 */
	  height: 25px; /* 设置高度 */
	max-width: 100%; /* 设置最大宽度为容器宽度的100%，防止溢出 */
	  object-fit: contain; /* 保持图像的完整，同时调整图像以适应容器 */
}
	
.imgtime{
	width:10%; /* 设置宽度为自动，保持原始宽高比 */
	  height: 25px; /* 设置高度 */
	max-width: 100%; /* 设置最大宽度为容器宽度的100%，防止溢出 */
	  object-fit: contain; /* 保持图像的完整，同时调整图像以适应容器 */
}
.topbox h3{
  font-size: 2rem;
}
	
.eventtitle{
	font-size: 30px;
	font-weight: 900;
}
.bable_span{
  display: inline-block;
  margin: 1rem;
  margin-left: 0;
  font-size: 25px;
}
.eventDetail{
  font-size: 20px;

}
.activity-cards {
  display: none;
}
.eventOrganizer{
  /* font-size: 1.5rem; */
  font-size: 20px;
  line-height: 2rem;
  vertical-align: middle;
}
.text{
  font-size: 25px;
  word-spacing:1rem;
}
.title{
  font-size: 25px;
  font-weight: 900;
  display: block;
}
.detailpic{
  width: 90%;
  height:300px;
  margin-left: 3%;
  border-radius: 1rem;
  margin-bottom: .5rem;
  margin-top: 1rem;
}
.outcome{

  height: 3%;
  widows: 100%;
}
.topbox{
  margin:1rem;
  margin-top: .5rem;
  border-bottom: 1px dashed #ccc !important;
}
.topbox h3{
  margin-bottom: .5rem;
  margin-top: 0rem;
}
.locationDetail{
  font-size: 1rem;
  line-height: 2rem;
}
.time{
  font-size: 20px;
  line-height: 2rem;
}
.detail{
  margin:1rem;
  border-bottom: 1px dashed #ccc !important;
}
.bable{
  margin:1rem;
  border-bottom: 1px dashed #ccc !important;
  height: 10%;
}
.outcome{
  color:#626467;
  font-size: 1rem;
  font-weight: 700;
  font-family: 'Inter';
}
svg{
  width: 30px;
  height: 30px;
  vertical-align: middle;
}
.time img{
  width: 30px;
  height: 30px;
  vertical-align: middle;
}
.activity-pic{
  height: 80%;
  align-self: center; 
  margin-left: -2%;
}
.activity-info .date{
  font-weight: 700;
  color: #EF756E;
  font-size: .7rem;
  line-height: 1.5vh;
}
.container {
  display: flex;
  flex-direction: column;
  height: 100%;
}
.deleteIcon{
  margin-right: -40%;
}


.top-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  background-color: #fff;
  
  width: 90%;
  margin: 0%;
}

.search-bar {
  display: flex;
  align-items: center;
}

.search-bar input {
  flex: 1;
  padding: 5px;
  border: 1px solid #ddd;
  border-radius: 20px;
  outline: none;
}

.search-bar button {
  padding: 5px 10px;
  background-color: #ef756e;
  color: #fff;
  border: none;
  border-radius: 20px;
  cursor: pointer;
}



.activity-cards {
  flex: 1;
  overflow-y: auto;
  width: 95%;
}

.activity-card {
  display: flex; /* 使活动卡片横向排列 */
  border: 1px solid #ddd;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 10px;
}

.activity-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-self: center; 
  margin-left: 2%;
}

.activity-info .title {
  font-size: 1rem;
  font-weight: bold;
  line-height: 2.5vh
}

.activity-info .details {
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
}

.activity-info .organizer {
  font-weight: 400;
  font-size: 0.7rem;
  margin-right: 56%;
  line-height: 1.5vh;
}
.activity-info .location {
  font-weight: 400;
  font-size: 0.7rem;
  margin-left: 15%;
  margin-top: -10%
}
.sidepic{
  align-self: center;
}
.likeicon{
  
}
.organizericon
{
  line-height: 3vh;
  margin-left: 3px;
}
.shareicon
{
  
}
.top-nav input{
  font-size: 1rem;
  font-weight: 600;
}
.top-nav input::placeholder
{
  color:#EF756E;

}
/* 响应式布局 */
/* @media (max-width: 768px) {
  .top-nav, .bottom-nav {
    flex-direction: column;
    align-items: center;
  }

  .top-nav .search-bar {
    width: 100%;
    margin-top: 10px;
  }

  .top-nav .tabs, .bottom-nav .tab {
    margin: 5px 0;
  }
} */
.logo{
  /* margin: 0 auto; */
  display: flex; /* 使用 Flexbox 布局 */
  align-items: center; /* 垂直居中对齐 */
  
}
.logo img {
  width: auto;
  margin-left: 20%;
  /* margin: 0 auto; */
}
.returnbutton{
  margin-left: 10px; /* 根据需要调整左边距 */
  padding: 5px 10px; /* 添加一些内边距 */
  border: 1px solid #fff; /* 设置白色边框 */
  background-color: transparent; /* 透明背景 */
  
  border-radius: 5px; /* 添加圆角 */
  cursor: pointer; /* 鼠标悬停时显示手形光标 */
}
</style>