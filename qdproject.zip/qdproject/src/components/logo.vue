<template>
    <div class="logo">
        <img src="../../public/logo.png" alt="活动力Logo">     
      </div>
</template>
<script>
export default {
  data()
  {
    
  },
  methods: {
   
  },
}

</script>
<style scoped>
.logo{
  margin: 0 auto;
}
.logo img {
  width: 100%;
}
</style>