<template>
  <div class="dropdown-selector">
    <select v-model="selectedTag"  @change="changeColor" ref="selectElement">
      <option v-for="(item, index) in tags1" :key="index" :value="item.value" :class="{ 'selected-option': item.value === selectedTag }">

        <!-- <span v-html="safeSvg(tag.svg)"></span> -->
        <!-- <img :src="item.tagicon" alt=""> -->
        {{ item.text }}
      </option>
    </select>

    <select v-model="selectedDate">
      <option value="">请选择日期</option>
      <option value="today">今天</option>
      <option value="yesterday">昨天</option>
    </select>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'DropdownSelector',
  data() {
    return {
      tags1: [
      { index:1,text: '请选择标签', value: '',tagicon:"seting.png"},
      { index:2,text: '选项 1', value: 'option1' },
      { index:3,text: '选项 2', value: 'option2' },
      { index:4,text: '选项 3', value: 'option3' }

      ], 
      tags2: [
      { text: '请选择标签', value: '',tagicon:"seting.png"},
      { text: '选项 1', value: 'option1' },
      { text: '选项 2', value: 'option2' },
      { text: '选项 3', value: 'option3' }

      ],
      selectedTag: '', // 当前选中的标签
      selectedDate: 'today', // 默认选中的日期
    };
  },
  methods: {
    fetchTags() {
      // 这里我们假设有一个API端点可以获取标签数据
      // axios.get('')//空接口
      //   .then(response => {
      //     this.tags = response.data; // 假设返回的数据格式是{ data: ['类别1', '类别2'] }
      //   })
      //   .catch(error => {
      //     console.error('Error fetching tags:', error);
      //   });
    },
    changeColor(event) {
      const selectElement = this.$refs.selectElement;
  // 遍历所有选项并移除 selected-option 类
  for (let i = 0; i < selectElement.options.length; i++) {
    selectElement.options[i].classList.remove('selected-option');
  }
  // 获取选中的选项
  const selectedOption = selectElement.options[selectElement.selectedIndex];
  // 为选中的选项添加 selected-option 类
  if (selectedOption) {
    selectedOption.classList.add('selected-option');
  }
      
    }
  },
  created() {
    // 组件创建时获取标签数据
    this.fetchTags();
  },
};
</script>

<style scoped>
/* 在这里添加你的CSS样式 */
.dropdown-selector {
  display: flex;
 
}

select {
  padding: 8px;
  margin: 0 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  background-color:#FFF5EE ;
  border-radius: 30px;
  font-weight: 700;
}
.selected-option {
  background-color: red;
}
</style>