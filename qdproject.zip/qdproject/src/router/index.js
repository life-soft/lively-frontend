import { createRouter, createWebHistory } from 'vue-router'
import searchview from "../views/searchView.vue"
import likeview from "../views/likeView.vue"
import homeview from "../views/homeView.vue"
import contentview from "../views/contentView.vue"
const routes = [
  {
    path: '/',
    name: 'searchview',
    component: searchview
  },
  {
    path: '/homeview',
    name: 'homeview',
    component: homeview
  },
  {
    path: '/contentview/:index',
    name: 'contentview',
    component: contentview
  },
  {
    path: '/likeview',
    name: 'likeview',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import('../views/likeView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
