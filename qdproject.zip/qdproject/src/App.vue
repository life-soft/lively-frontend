<!-- <style lang="scss">
	@import "uview-ui/index.scss";
</style> -->
<template>
  
  <router-view/>
</template>

