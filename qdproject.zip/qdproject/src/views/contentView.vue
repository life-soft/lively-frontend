<template>
  <div class="container">
    <logo></logo>
    <div v-if="card">
    <!-- 在数据实际更新之前，模板可能已经尝试渲染。 -->
    <p>卡片索引: {{ card.index }}</p>
    <img src="../../public/huodongpic.png" alt="" class="detailpic">
    <div class="topbox">
      <h3>
        {{ card.title }}
      </h3>
      <h4>
        {{ card.organizer }}
        {{ card.location }}
      </h4>
    </div>
    <div class="detail">
      <h4>活动详情</h4>
      <p>
        活动详情活动详情活动详情活动详情活动详情
      </p>
    </div>
    <div class="bable">
      <h4>活动标签</h4>
    </div>
  </div>
    
  </div>
  <card ref="cardComponentRef" style="display: none;"></card>

  
   <bottomtab></bottomtab>
</template>

<script>
import { ElIcon } from 'element-plus'
import { Close } from '@element-plus/icons-vue'
import 'element-plus/es/components/icon/style/css'
import bottomtab from '../components/bottomtabs.vue';
import downselect from '../components/downselect.vue';
import logo from "../components/logo.vue"
import card from "../components/card.vue"
// import { Close } from "@element-plus/icons";

export default {
  
  data() {
    
    return {    
      card:null,
      useindexcard:this.index,
    };
  },
  
  components: {
    bottomtab,
    downselect,
    logo,
    card,
  },
  created() {
    // 组件创建时获取 index 参数
    //this.index = this.$route.params.index;
    // const cardComponent = this.$refs.cardComponent;
    // const index = this.$route.params.index;
    // this.selectedCard = cardComponent.getCardByIndex(index);
  },
  computed: {
    // 使用计算属性来获取 index 参数
    index() {
      return this.$route.params.index;
    }
  },
  mounted() {
  try {
    // 确保 cardComponentRef 不是 undefined
    const cardInstance = this.$refs.cardComponentRef;
    console.log("进入第" + this.$route.params.index + "个card");
    // 确保 indexcard 是一个数字
    const indexcard = parseInt(this.$route.params.index, 10);
    if (cardInstance) {
      // 调用 getCardByIndex 方法
      const card = cardInstance.getCardByIndex(indexcard); // 现在 indexcard 是一个数字
      // 使用获取到的 card 数据
      console.log(card);
      console.log(card.title);
      this.card = card;
      this.card.pic="public/"+card.pic
    }
  } catch (error) {
    console.error(error);
  }
}
};

</script>

<style scoped>
.detailpic{
  width: 80%;
  height:35%;
  margin-left: 10%;
}
.outcome{

  height: 3%;
  widows: 100%;
}
.topbox{
  border: 1px solid #E0E0E0;
}
.detail{
  border: 1px solid #E0E0E0;
}
.noutcome{
  color:#626467;
  font-size: 1rem;
  font-weight: 700;
  font-family: 'Inter';
}
svg{
  width: 1rem;
  height: 1rem;
}

.activity-pic{
  height: 80%;
  align-self: center; 
  margin-left: -2%;
}
.activity-info .date{
  font-weight: 700;
  color: #EF756E;
  font-size: .7rem;
  line-height: 1.5vh;
}
.container {
  display: flex;
  flex-direction: column;
  height: 90%;
}
.deleteIcon{
  margin-right: -40%;
}
.logo{
  margin: 0 auto;
}

.top-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  background-color: #fff;
  
  width: 90%;
  margin: 0%;
}

.logo img {
  width: 100%;
}

.search-bar {
  display: flex;
  align-items: center;
}

.search-bar input {
  flex: 1;
  padding: 5px;
  border: 1px solid #ddd;
  border-radius: 20px;
  outline: none;
}

.search-bar button {
  padding: 5px 10px;
  background-color: #ef756e;
  color: #fff;
  border: none;
  border-radius: 20px;
  cursor: pointer;
}



.activity-cards {
  flex: 1;
  overflow-y: auto;
  width: 95%;
}

.activity-card {
  display: flex; /* 使活动卡片横向排列 */
  border: 1px solid #ddd;
  border-radius: 10px;
  margin-bottom: 10px;
  padding: 10px;
}

.activity-info {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-self: center; 
  margin-left: 2%;
}

.activity-info .title {
  font-size: 1rem;
  font-weight: bold;
  line-height: 2.5vh
}

.activity-info .details {
  display: flex;
  justify-content: space-between;
  margin-top: 10px;
}

.activity-info .organizer {
  font-weight: 400;
  font-size: 0.7rem;
  margin-right: 56%;
  line-height: 1.5vh;
}
.activity-info .location {
  font-weight: 400;
  font-size: 0.7rem;
  margin-left: 15%;
  margin-top: -10%
}
.sidepic{
  align-self: center;
}
.likeicon{
  
}
.organizericon
{
  line-height: 3vh;
}
.shareicon
{
  
}
.top-nav input{
  font-size: 1rem;
  font-weight: 600;
}
.top-nav input::placeholder
{
  color:#EF756E;

}
/* 响应式布局 */
/* @media (max-width: 768px) {
  .top-nav, .bottom-nav {
    flex-direction: column;
    align-items: center;
  }

  .top-nav .search-bar {
    width: 100%;
    margin-top: 10px;
  }

  .top-nav .tabs, .bottom-nav .tab {
    margin: 5px 0;
  }
} */
</style>